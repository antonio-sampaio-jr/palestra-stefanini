package com.abctreinamentos.novasfuncionalidades.aux;

public sealed class Departamento permits Marketing, Vendas, TI, Financas, Design{
	
}
