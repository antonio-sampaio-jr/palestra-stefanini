package com.abctreinamentos.novasfuncionalidades.aux;

public final class Design extends Departamento {
	
	private String nomeProduto;
	private String descricao;
	
	public Design(String nomeProduto, String descricao) {
		super();
		this.nomeProduto = nomeProduto;
		this.descricao = descricao;
	}

	public String getNomeProduto() {
		return nomeProduto;
	}

	public void setNomeProduto(String nomeProduto) {
		this.nomeProduto = nomeProduto;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	

}
