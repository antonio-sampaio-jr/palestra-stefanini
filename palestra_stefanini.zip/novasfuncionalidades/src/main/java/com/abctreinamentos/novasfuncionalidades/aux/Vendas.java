package com.abctreinamentos.novasfuncionalidades.aux;

public final class Vendas extends Departamento {
	
	private String produto;
    private double valor;
    
	public Vendas(String produto, double valor) {
		super();
		this.produto = produto;
		this.valor = valor;
	}

	public String getProduto() {
		return produto;
	}

	public void setProduto(String produto) {
		this.produto = produto;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}
    
    

}
