package com.abctreinamentos.novasfuncionalidades.aux.novaversao;

public record RDesign (String nomeProduto, String descricao) implements IDepartamento { }
