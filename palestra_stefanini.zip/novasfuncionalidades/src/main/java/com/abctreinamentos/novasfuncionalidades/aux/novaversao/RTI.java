package com.abctreinamentos.novasfuncionalidades.aux.novaversao;

public record RTI (String nomeProjeto, String responsavelProjeto) implements IDepartamento {
		
}
