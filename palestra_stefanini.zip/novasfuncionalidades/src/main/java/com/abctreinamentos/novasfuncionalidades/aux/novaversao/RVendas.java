package com.abctreinamentos.novasfuncionalidades.aux.novaversao;

public record RVendas (String produto, double valor) implements IDepartamento{
		
}
